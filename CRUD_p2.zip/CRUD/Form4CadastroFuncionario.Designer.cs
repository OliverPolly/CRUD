﻿namespace CRUD
{
    partial class Form4CadastroFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4CadastroFuncionario));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodigoF = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtEmailF = new System.Windows.Forms.TextBox();
            this.txtFuncaoF = new System.Windows.Forms.TextBox();
            this.cbSexoF = new System.Windows.Forms.ComboBox();
            this.dtNascimentoF = new System.Windows.Forms.DateTimePicker();
            this.mtbCPFF = new System.Windows.Forms.MaskedTextBox();
            this.mtbTelefoneF = new System.Windows.Forms.MaskedTextBox();
            this.txtNomeF = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtNacionalidadeF = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridViewFuncionario = new System.Windows.Forms.DataGridView();
            this.btnExcluirF = new System.Windows.Forms.Button();
            this.btnVoltarF = new System.Windows.Forms.Button();
            this.btnEditarF = new System.Windows.Forms.Button();
            this.btnExibirF = new System.Windows.Forms.Button();
            this.btnSalvarF = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnCancelar = new System.Windows.Forms.Button();
            this.txtSalarioF = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFuncionario)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(808, 41);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(263, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cadastro de Funcionários";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Código";
            // 
            // txtCodigoF
            // 
            this.txtCodigoF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCodigoF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCodigoF.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodigoF.ForeColor = System.Drawing.Color.Lime;
            this.txtCodigoF.Location = new System.Drawing.Point(12, 80);
            this.txtCodigoF.Name = "txtCodigoF";
            this.txtCodigoF.ReadOnly = true;
            this.txtCodigoF.Size = new System.Drawing.Size(100, 18);
            this.txtCodigoF.TabIndex = 105;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(703, 64);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 44);
            this.pictureBox1.TabIndex = 132;
            this.pictureBox1.TabStop = false;
            // 
            // txtEmailF
            // 
            this.txtEmailF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtEmailF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmailF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailF.Location = new System.Drawing.Point(228, 242);
            this.txtEmailF.Name = "txtEmailF";
            this.txtEmailF.Size = new System.Drawing.Size(300, 22);
            this.txtEmailF.TabIndex = 8;
            // 
            // txtFuncaoF
            // 
            this.txtFuncaoF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtFuncaoF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFuncaoF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFuncaoF.Location = new System.Drawing.Point(174, 186);
            this.txtFuncaoF.Name = "txtFuncaoF";
            this.txtFuncaoF.Size = new System.Drawing.Size(354, 22);
            this.txtFuncaoF.TabIndex = 5;
            // 
            // cbSexoF
            // 
            this.cbSexoF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbSexoF.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbSexoF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSexoF.FormattingEnabled = true;
            this.cbSexoF.Items.AddRange(new object[] {
            "F",
            "M",
            ""});
            this.cbSexoF.Location = new System.Drawing.Point(30, 184);
            this.cbSexoF.Name = "cbSexoF";
            this.cbSexoF.Size = new System.Drawing.Size(110, 24);
            this.cbSexoF.TabIndex = 4;
            // 
            // dtNascimentoF
            // 
            this.dtNascimentoF.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dtNascimentoF.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNascimentoF.Location = new System.Drawing.Point(532, 129);
            this.dtNascimentoF.Name = "dtNascimentoF";
            this.dtNascimentoF.Size = new System.Drawing.Size(213, 20);
            this.dtNascimentoF.TabIndex = 3;
            // 
            // mtbCPFF
            // 
            this.mtbCPFF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.mtbCPFF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtbCPFF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbCPFF.Location = new System.Drawing.Point(383, 127);
            this.mtbCPFF.Mask = "000.000.000-00";
            this.mtbCPFF.Name = "mtbCPFF";
            this.mtbCPFF.Size = new System.Drawing.Size(116, 22);
            this.mtbCPFF.TabIndex = 2;
            // 
            // mtbTelefoneF
            // 
            this.mtbTelefoneF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.mtbTelefoneF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtbTelefoneF.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbTelefoneF.Location = new System.Drawing.Point(30, 242);
            this.mtbTelefoneF.Mask = "(00) 00000-0000";
            this.mtbTelefoneF.Name = "mtbTelefoneF";
            this.mtbTelefoneF.Size = new System.Drawing.Size(155, 20);
            this.mtbTelefoneF.TabIndex = 7;
            // 
            // txtNomeF
            // 
            this.txtNomeF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtNomeF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNomeF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomeF.Location = new System.Drawing.Point(30, 127);
            this.txtNomeF.Name = "txtNomeF";
            this.txtNomeF.Size = new System.Drawing.Size(316, 22);
            this.txtNomeF.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(27, 223);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 16);
            this.label16.TabIndex = 130;
            this.label16.Text = "Telefone";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(225, 223);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 16);
            this.label14.TabIndex = 126;
            this.label14.Text = "E-maill";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(171, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 112;
            this.label7.Text = "Função";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(27, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 16);
            this.label6.TabIndex = 111;
            this.label6.Text = "*Sexo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(529, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 16);
            this.label5.TabIndex = 108;
            this.label5.Text = "*Data de Nascimento";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(561, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 16);
            this.label4.TabIndex = 106;
            this.label4.Text = "*Salário";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(380, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 104;
            this.label3.Text = "*CPF";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(27, 108);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(42, 16);
            this.label17.TabIndex = 103;
            this.label17.Text = "*Nome";
            // 
            // txtNacionalidadeF
            // 
            this.txtNacionalidadeF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtNacionalidadeF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNacionalidadeF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNacionalidadeF.Location = new System.Drawing.Point(564, 240);
            this.txtNacionalidadeF.Name = "txtNacionalidadeF";
            this.txtNacionalidadeF.Size = new System.Drawing.Size(181, 22);
            this.txtNacionalidadeF.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(561, 221);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 16);
            this.label8.TabIndex = 106;
            this.label8.Text = "*Nacionalidade";
            // 
            // dataGridViewFuncionario
            // 
            this.dataGridViewFuncionario.AllowUserToAddRows = false;
            this.dataGridViewFuncionario.AllowUserToDeleteRows = false;
            this.dataGridViewFuncionario.AllowUserToResizeRows = false;
            this.dataGridViewFuncionario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFuncionario.Location = new System.Drawing.Point(30, 283);
            this.dataGridViewFuncionario.Name = "dataGridViewFuncionario";
            this.dataGridViewFuncionario.ReadOnly = true;
            this.dataGridViewFuncionario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewFuncionario.Size = new System.Drawing.Size(626, 173);
            this.dataGridViewFuncionario.TabIndex = 133;
            this.dataGridViewFuncionario.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // btnExcluirF
            // 
            this.btnExcluirF.BackColor = System.Drawing.Color.Red;
            this.btnExcluirF.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExcluirF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluirF.Location = new System.Drawing.Point(670, 402);
            this.btnExcluirF.Name = "btnExcluirF";
            this.btnExcluirF.Size = new System.Drawing.Size(75, 24);
            this.btnExcluirF.TabIndex = 13;
            this.btnExcluirF.Text = "Excluir";
            this.btnExcluirF.UseVisualStyleBackColor = false;
            this.btnExcluirF.Click += new System.EventHandler(this.btnExcluirF_Click);
            // 
            // btnVoltarF
            // 
            this.btnVoltarF.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnVoltarF.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVoltarF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltarF.Location = new System.Drawing.Point(670, 432);
            this.btnVoltarF.Name = "btnVoltarF";
            this.btnVoltarF.Size = new System.Drawing.Size(75, 24);
            this.btnVoltarF.TabIndex = 14;
            this.btnVoltarF.Text = "Voltar";
            this.toolTip1.SetToolTip(this.btnVoltarF, "Voltar para tela inicial");
            this.btnVoltarF.UseVisualStyleBackColor = false;
            this.btnVoltarF.Click += new System.EventHandler(this.btnVoltarF_Click);
            // 
            // btnEditarF
            // 
            this.btnEditarF.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnEditarF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarF.Location = new System.Drawing.Point(670, 343);
            this.btnEditarF.Name = "btnEditarF";
            this.btnEditarF.Size = new System.Drawing.Size(75, 24);
            this.btnEditarF.TabIndex = 15;
            this.btnEditarF.Text = "Editar";
            this.btnEditarF.UseVisualStyleBackColor = true;
            this.btnEditarF.Click += new System.EventHandler(this.btnEditarF_Click);
            // 
            // btnExibirF
            // 
            this.btnExibirF.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExibirF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExibirF.Location = new System.Drawing.Point(670, 313);
            this.btnExibirF.Name = "btnExibirF";
            this.btnExibirF.Size = new System.Drawing.Size(75, 24);
            this.btnExibirF.TabIndex = 11;
            this.btnExibirF.Text = "Exibir";
            this.btnExibirF.UseVisualStyleBackColor = true;
            this.btnExibirF.Click += new System.EventHandler(this.btnExibirF_Click);
            // 
            // btnSalvarF
            // 
            this.btnSalvarF.BackColor = System.Drawing.Color.Lime;
            this.btnSalvarF.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalvarF.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvarF.Location = new System.Drawing.Point(670, 283);
            this.btnSalvarF.Name = "btnSalvarF";
            this.btnSalvarF.Size = new System.Drawing.Size(75, 24);
            this.btnSalvarF.TabIndex = 10;
            this.btnSalvarF.Text = "Salvar";
            this.btnSalvarF.UseVisualStyleBackColor = false;
            this.btnSalvarF.Click += new System.EventHandler(this.btnSalvarF_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCancelar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Location = new System.Drawing.Point(670, 373);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 135;
            this.btnCancelar.Text = "Cancelar";
            this.toolTip1.SetToolTip(this.btnCancelar, "Cancelar");
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // txtSalarioF
            // 
            this.txtSalarioF.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtSalarioF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSalarioF.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioF.Location = new System.Drawing.Point(564, 186);
            this.txtSalarioF.Name = "txtSalarioF";
            this.txtSalarioF.Size = new System.Drawing.Size(181, 22);
            this.txtSalarioF.TabIndex = 136;
            this.txtSalarioF.TextChanged += new System.EventHandler(this.txtSalarioF_TextChanged);
            // 
            // Form4CadastroFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(769, 481);
            this.Controls.Add(this.txtSalarioF);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnExcluirF);
            this.Controls.Add(this.btnVoltarF);
            this.Controls.Add(this.btnEditarF);
            this.Controls.Add(this.btnExibirF);
            this.Controls.Add(this.btnSalvarF);
            this.Controls.Add(this.dataGridViewFuncionario);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtEmailF);
            this.Controls.Add(this.txtFuncaoF);
            this.Controls.Add(this.cbSexoF);
            this.Controls.Add(this.dtNascimentoF);
            this.Controls.Add(this.txtNacionalidadeF);
            this.Controls.Add(this.mtbCPFF);
            this.Controls.Add(this.mtbTelefoneF);
            this.Controls.Add(this.txtNomeF);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtCodigoF);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form4CadastroFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFuncionario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCodigoF;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtEmailF;
        private System.Windows.Forms.TextBox txtFuncaoF;
        private System.Windows.Forms.ComboBox cbSexoF;
        private System.Windows.Forms.DateTimePicker dtNascimentoF;
        private System.Windows.Forms.MaskedTextBox mtbCPFF;
        private System.Windows.Forms.MaskedTextBox mtbTelefoneF;
        private System.Windows.Forms.TextBox txtNomeF;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtNacionalidadeF;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridViewFuncionario;
        private System.Windows.Forms.Button btnExcluirF;
        private System.Windows.Forms.Button btnVoltarF;
        private System.Windows.Forms.Button btnEditarF;
        private System.Windows.Forms.Button btnExibirF;
        private System.Windows.Forms.Button btnSalvarF;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.TextBox txtSalarioF;
    }
}