﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRUD.MODEL;
using CRUD.BLL;

namespace CRUD
{
    public partial class Form4CadastroFuncionario : Form
    {
        public Form4CadastroFuncionario()
        {
            InitializeComponent();
        }
        #region Botões
        private void btnExibirF_Click(object sender, EventArgs e)
        {
            try
            {
                ListarF();
                LimparF();
            }
            catch (Exception erro)
            {
                MessageBox.Show("erro ao exibir os dados\n" + erro, "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnSalvarF_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            SalvarF(funcionario);
        }
        private void btnEditarF_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            AlterarF(funcionario);
        }
        private void btnVoltarF_Click(object sender, EventArgs e)
        {
            Inicio formTelaInicial = new Inicio();
            formTelaInicial.Show();
            this.Hide();
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimparF();
            ListarF();
            btnSalvarF.Enabled = true;
            btnExibirF.Enabled = true;
        }

        private void btnExcluirF_Click(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            ExcluirF(funcionario);
        }
        #endregion
        #region  Duplo clique
        //metodo duplo clique no data gried view
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtCodigoF.Text = dataGridViewFuncionario.CurrentRow.Cells[0].Value.ToString();
            txtNomeF.Text = dataGridViewFuncionario.CurrentRow.Cells[1].Value.ToString();
            mtbCPFF.Text = dataGridViewFuncionario.CurrentRow.Cells[4].Value.ToString();
            dtNascimentoF.Text = dataGridViewFuncionario.CurrentRow.Cells[5].Value.ToString();
            cbSexoF.Text = dataGridViewFuncionario.CurrentRow.Cells[6].Value.ToString();
            txtFuncaoF.Text = dataGridViewFuncionario.CurrentRow.Cells[3].Value.ToString();
            txtSalarioF.Text = dataGridViewFuncionario.CurrentRow.Cells[7].Value.ToString();
            mtbTelefoneF.Text = dataGridViewFuncionario.CurrentRow.Cells[9].Value.ToString();
            txtEmailF.Text = dataGridViewFuncionario.CurrentRow.Cells[2].Value.ToString();
            txtNacionalidadeF.Text = dataGridViewFuncionario.CurrentRow.Cells[8].Value.ToString();
            btnSalvarF.Enabled = false;
            btnExibirF.Enabled = false;
        }
        #endregion
        #region Listar
        private void ListarF()
        {
            FuncionarioBLL funcionarioBLL = new FuncionarioBLL();
            dataGridViewFuncionario.DataSource = funcionarioBLL.ListarF();

            //remover colunas
            //dataGridView1.Columns[4].Visible = false;

            //renomerar colunas 
            dataGridViewFuncionario.Columns[0].HeaderText = "Id";
            dataGridViewFuncionario.Columns[1].HeaderText = "Nome";
            dataGridViewFuncionario.Columns[2].HeaderText = "E-mail";
            dataGridViewFuncionario.Columns[3].HeaderText = "Função";
            dataGridViewFuncionario.Columns[4].HeaderText = "CPF";
            dataGridViewFuncionario.Columns[5].HeaderText = "Nascimento";
            dataGridViewFuncionario.Columns[6].HeaderText = "Sexo";
            dataGridViewFuncionario.Columns[7].HeaderText = "Salário";
            dataGridViewFuncionario.Columns[8].HeaderText = "Nacionalidade";

            //ajustar largura coluna
            // dataGridView1.Columns[0].Width = 45;
        }
        #endregion
        #region Limpar
        //metodo para limpar 
        public void LimparF()
        {
            txtCodigoF.Clear();

            txtNomeF.Clear();
            txtFuncaoF.Clear();
            txtEmailF.Clear();
            txtNacionalidadeF.Clear();
            cbSexoF.SelectedIndex = -1;
            txtSalarioF.Clear();
            mtbCPFF.Clear();
            mtbTelefoneF.Clear();
            cbSexoF.BackColor = Color.White;
            mtbCPFF.BackColor = Color.White;
            txtNomeF.BackColor = Color.White;


        }
        #endregion
        #region Salvar
        private void SalvarF(Funcionario funcionario)

        {
            FuncionarioBLL funcionarioBLL = new FuncionarioBLL();
            if (txtNomeF.Text.Trim() == string.Empty || txtNomeF.Text.Trim().Length < 3)
            {
                MessageBox.Show("O campo NOME não pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cbSexoF.BackColor = Color.White;
                mtbCPFF.BackColor = Color.White;
                txtNomeF.BackColor = Color.LightCoral;
            }
            else if (!mtbCPFF.MaskCompleted)
            {
                MessageBox.Show("O campo CPF nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNomeF.BackColor = Color.White;
                cbSexoF.BackColor = Color.White;
                mtbCPFF.BackColor = Color.LightCoral;

            }
            else if (cbSexoF.Text == string.Empty)
            {
                MessageBox.Show("O campo SEXO nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNomeF.BackColor = Color.White;

                mtbCPFF.BackColor = Color.White;
                cbSexoF.BackColor = Color.LightCoral;
            }
            else
            {

                funcionario.NomeF = txtNomeF.Text;
                mtbCPFF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                funcionario.CpfF = mtbCPFF.Text;
                
                funcionario.SalarioF = Convert.ToDouble(txtSalarioF.Text);
                funcionario.FuncaoF = txtFuncaoF.Text;
                funcionario.EmailF = txtEmailF.Text;
                funcionario.NascimentoF = dtNascimentoF.Text;
                funcionario.SexoF = cbSexoF.Text;
                funcionario.NacionalidadeF = txtNacionalidadeF.Text;
                mtbTelefoneF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                funcionario.Telefone = mtbTelefoneF.Text;


                funcionarioBLL.SalvarF(funcionario);
                MessageBox.Show("Cadastro realizado com sucesso!", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparF();
            }
        }
        #endregion
        #region Alterar
        private void AlterarF(Funcionario funcionario)
        {
            FuncionarioBLL funcionarioBLL = new FuncionarioBLL();
            if (txtNomeF.Text.Trim() == string.Empty || txtNomeF.Text.Trim().Length < 3)
            {
                MessageBox.Show("O campo NOME não pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cbSexoF.BackColor = Color.White;
                mtbCPFF.BackColor = Color.White;
                txtNomeF.BackColor = Color.LightCoral;
            }
            else if (!mtbCPFF.MaskCompleted)
            {
                MessageBox.Show("O campo CPF nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNomeF.BackColor = Color.White;
                cbSexoF.BackColor = Color.White;
                mtbCPFF.BackColor = Color.LightCoral;

            }
            else if (cbSexoF.Text == string.Empty)
            {
                MessageBox.Show("O campo SEXO nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNomeF.BackColor = Color.White;

                mtbCPFF.BackColor = Color.White;
                cbSexoF.BackColor = Color.LightCoral;
            }
            else
            {
                funcionario.IdF = Convert.ToInt32(txtCodigoF.Text);
                funcionario.NomeF = txtNomeF.Text;
                mtbCPFF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                funcionario.CpfF = mtbCPFF.Text;
                
                funcionario.SalarioF = Convert.ToDouble(txtSalarioF.Text);
                funcionario.FuncaoF = txtFuncaoF.Text;
                funcionario.EmailF = txtEmailF.Text;
                funcionario.NascimentoF = dtNascimentoF.Text;
                funcionario.SexoF = cbSexoF.Text;
                funcionario.NacionalidadeF = txtNacionalidadeF.Text;
                mtbTelefoneF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                funcionario.Telefone = mtbTelefoneF.Text;


                funcionarioBLL.AlterarF(funcionario);
                MessageBox.Show("Alterado com sucesso!", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparF();
                btnSalvarF.Enabled = true;
                btnExibirF.Enabled = true;
            }
        }
        #endregion
        #region Excluir
        private void ExcluirF(Funcionario funcionario)
        {
            FuncionarioBLL funcionarioBLL = new FuncionarioBLL();
            if (txtCodigoF.Text == string.Empty)
            {
                MessageBox.Show("Selecione um cadastro para excluir", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (MessageBox.Show("Deseja excluir o cadastro selecionado?", "Alerta", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                funcionario.IdF = Convert.ToInt32(txtCodigoF.Text);
                funcionarioBLL.ExcluirF(funcionario);
                MessageBox.Show("Excluido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparF();
                btnSalvarF.Enabled = true;
                btnExibirF.Enabled = true;
            }
        }
        #endregion

        private void txtSalarioF_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

       
    

