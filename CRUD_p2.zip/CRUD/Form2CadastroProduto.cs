﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRUD.MODEL;
using CRUD.BLL;

namespace CRUD
{
    public partial class Form2CadastroProduto : Form
    {
        public Form2CadastroProduto()
        {
            InitializeComponent();
        }
        #region sem querer
        private void Form2CadastroProduto_Load(object sender, EventArgs e)
        {

        }

        private void txtValortotalP_TextChanged(object sender, EventArgs e)
        {

        }
        #endregion
        #region Botões
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double numero1;
            double numero2;
            double resultado;

            numero1 = Double.Parse(txtQtdPro.Text);
            numero2 = Double.Parse(txtValoruniP.Text);

            resultado = numero1 * numero2;
            txtValortotalP.Text = resultado.ToString();
        }

        private void txtValoruniP_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExibirP_Click(object sender, EventArgs e)
        {
            try
            {
                ListarP();
                LimparP();

            }
            catch (Exception erro)
            {
                MessageBox.Show("erro ao exibir os dados\n" + erro, "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void btnSalvarP_Click(object sender, EventArgs e)
        {
            Produto produto = new Produto();
            SalvarP(produto);
        }
        private void btnEditarP_Click(object sender, EventArgs e)
        {
            Produto produto = new Produto();
            AlterarP(produto);

        }
        private void btnVoltarP_Click(object sender, EventArgs e)
        {
            Inicio formTelaInicial = new Inicio();
            formTelaInicial.Show();
            this.Hide();
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimparP();
            ListarP();
            btnSalvarP.Enabled = true;
            btnExibirP.Enabled = true;
        }
        private void btnExcluirP_Click(object sender, EventArgs e)
        {
            Produto produto = new Produto();
            ExcluirP(produto);

        }


        #endregion
        #region Duplo clique
        //metodo duplo clique no data gried view
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtCodigoP.Text = dataGridViewProdutp.CurrentRow.Cells[0].Value.ToString();
            txtCategoriaP.Text = dataGridViewProdutp.CurrentRow.Cells[2].Value.ToString();
            txtDescriP.Text = dataGridViewProdutp.CurrentRow.Cells[3].Value.ToString();
            txtQtdPro.Text = dataGridViewProdutp.CurrentRow.Cells[1].Value.ToString();
            txtValortotalP.Text = dataGridViewProdutp.CurrentRow.Cells[5].Value.ToString();
            txtValoruniP.Text = dataGridViewProdutp.CurrentRow.Cells[4].Value.ToString();
            txtObservacaoP.Text = dataGridViewProdutp.CurrentRow.Cells[6].Value.ToString();
            btnSalvarP.Enabled = false;
            btnExibirP.Enabled = false;
        }
        #endregion
        #region Listar
        private void ListarP()
        {
            ProdutoBLL produtoBLL = new ProdutoBLL();
            dataGridViewProdutp.DataSource = produtoBLL.ListarP();

            //remover colunas
            // dataGridView1.Columns[4].Visible = false;

            //renomerar colunas 
            //DataGridView1.Columns[0].HeaderText = "ID";

            //ajustar largura coluna
            //dataGridView1.Columns[0].Width = 45;

        }
        #endregion
        #region Limpar
        //metodo para limpar 
        public void LimparP()
        {
            txtCodigoP.Clear();
            txtCategoriaP.Clear();
            txtDescriP.Clear();
            txtObservacaoP.Clear();
            txtQtdPro.Clear();
            txtValortotalP.Clear();
            txtValoruniP.Clear();


        }
        #endregion
        #region Salvar
        private void SalvarP(Produto produto)
        {
            ProdutoBLL produtoBLL = new ProdutoBLL();
            if (txtDescriP.Text.Trim() == string.Empty || txtDescriP.Text.Trim().Length < 3)
            {
                MessageBox.Show("O campo DESCRIÇÃO não pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtQtdPro.BackColor = Color.White;
                txtValoruniP.BackColor = Color.White;
                txtDescriP.BackColor = Color.LightCoral;
            }
            else if (txtQtdPro.Text == string.Empty)
            {
                MessageBox.Show("O campo QUANTIDADE nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtDescriP.BackColor = Color.White;
                txtValoruniP.BackColor = Color.White;
                txtQtdPro.BackColor = Color.LightCoral;

            }
            else if (txtQtdPro.Text == string.Empty)
            {
                MessageBox.Show("O campo VALOR UNITÁRIO nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtDescriP.BackColor = Color.White;

                txtQtdPro.BackColor = Color.White;
                txtValoruniP.BackColor = Color.LightCoral;
            }
            else
            {

                produto.QuantidadeP = txtQtdPro.Text;
                produto.CategoriaP = txtCategoriaP.Text;
                produto.DescricaoP = txtDescriP.Text;
                produto.ValorunitarioP = txtValoruniP.Text;
                produto.ValortotalP = txtValortotalP.Text;
                produto.ObsevacaoP = txtObservacaoP.Text;


                produtoBLL.SalvarP(produto);
                MessageBox.Show("Cadastro realizado com sucesso!", "Aviso",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparP();

            }
        }
        #endregion
        #region Alterar
        private void AlterarP(Produto produto)
        {
            ProdutoBLL produtoBLL = new ProdutoBLL();
            if (txtDescriP.Text.Trim() == string.Empty || txtDescriP.Text.Trim().Length < 3)
            {
                MessageBox.Show("O campo DESCRIÇÃO não pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtQtdPro.BackColor = Color.White;
                txtValoruniP.BackColor = Color.White;
                txtDescriP.BackColor = Color.LightCoral;
            }
            else if (txtQtdPro.Text == string.Empty)
            {
                MessageBox.Show("O campo QUANTIDADE nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtDescriP.BackColor = Color.White;
                txtValoruniP.BackColor = Color.White;
                txtQtdPro.BackColor = Color.LightCoral;

            }
            else if (txtQtdPro.Text == string.Empty)
            {
                MessageBox.Show("O campo VALOR UNITÁRIO nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtDescriP.BackColor = Color.White;

                txtQtdPro.BackColor = Color.White;
                txtValoruniP.BackColor = Color.LightCoral;
            }
            else
            {
                produto.IdP = Convert.ToInt32(txtCodigoP.Text);
                produto.QuantidadeP = txtQtdPro.Text;
                produto.CategoriaP = txtCategoriaP.Text;
                produto.DescricaoP = txtDescriP.Text;
                produto.ValorunitarioP = txtValoruniP.Text;
                produto.ValortotalP = txtValortotalP.Text;
                produto.ObsevacaoP = txtObservacaoP.Text;


                produtoBLL.AlterarP(produto);
                MessageBox.Show("Alteração realizada com sucesso!", "Aviso",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparP();
                btnSalvarP.Enabled = true;
                btnExibirP.Enabled = true;
            }
        }

        #endregion
        #region Excluir
        private void ExcluirP(Produto produto)
        {
            ProdutoBLL produtoBLL = new ProdutoBLL();
            if (txtCodigoP.Text == string.Empty)
            {
                MessageBox.Show("Selecione um cadastro para excluir", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (MessageBox.Show("Deseja excluir o cadastro selecionado?", "Alerta", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                produto.IdP = Convert.ToInt32(txtCodigoP.Text);
                produtoBLL.ExcluirP(produto);
                MessageBox.Show("Excluido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimparP();
                btnSalvarP.Enabled = true;
                btnExibirP.Enabled = true;
            }
        }
        #endregion
    }
}
