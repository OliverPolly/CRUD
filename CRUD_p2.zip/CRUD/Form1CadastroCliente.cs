﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRUD.MODEL;
using CRUD.BLL;

namespace CRUD
{
    public partial class CadastroDeClientes : Form
    {
        public CadastroDeClientes()
        {
            InitializeComponent();
        }
        #region Botões Eventos
        private void btnExibir_Click(object sender, EventArgs e)
        {
            try
            {
                Listar();
                Limpar();
            }
            catch (Exception erro)
            {
                MessageBox.Show("erro ao exibir os dados\n" + erro, "Erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            Salvar(cliente);
        }
        private void btnEditar_Click(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            Alterar(cliente);

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            Excluir(cliente);

        }
        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Inicio formTelaInicial = new Inicio();
            formTelaInicial.Show();
            this.Hide();
        }
        private void btnCancelar_Click(object sender, EventArgs e)
        {

            Limpar();
            Listar();
            btnSalvar.Enabled = true;
            btnExibir.Enabled = true;

        }
        #endregion
        #region Duplo clique no DTV

        //metodo duplo clique no data gried view
        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            txtCodigo.Text = dataGridViewCliente.CurrentRow.Cells[0].Value.ToString();
            txtNome.Text = dataGridViewCliente.CurrentRow.Cells[1].Value.ToString();
            mtbCPF.Text = dataGridViewCliente.CurrentRow.Cells[2].Value.ToString();
            txtRG.Text = dataGridViewCliente.CurrentRow.Cells[3].Value.ToString();
            dtNascimento.Text = dataGridViewCliente.CurrentRow.Cells[12].Value.ToString();
            cbSexo.Text = dataGridViewCliente.CurrentRow.Cells[13].Value.ToString();
            txtEmail.Text = dataGridViewCliente.CurrentRow.Cells[7].Value.ToString();
            txtPais.Text = dataGridViewCliente.CurrentRow.Cells[10].Value.ToString();
            cbUF.Text = dataGridViewCliente.CurrentRow.Cells[9].Value.ToString();
            txtCidade.Text = dataGridViewCliente.CurrentRow.Cells[8].Value.ToString();
            txtNacionalidade.Text = dataGridViewCliente.CurrentRow.Cells[14].Value.ToString();
            mtbCEP.Text = dataGridViewCliente.CurrentRow.Cells[11].Value.ToString();
            txtEndereco.Text = dataGridViewCliente.CurrentRow.Cells[5].Value.ToString();
            txtBairro.Text = dataGridViewCliente.CurrentRow.Cells[15].Value.ToString();
            mtbTelefone.Text = dataGridViewCliente.CurrentRow.Cells[6].Value.ToString();
            txtRefComerciais.Text = dataGridViewCliente.CurrentRow.Cells[4].Value.ToString();
            
            btnSalvar.Enabled = false;
            btnExibir.Enabled = false;
        }
        #endregion Método duplo clique no data gried view
        #region Listar
        private void Listar()
        {
            ClienteBLL clienteBLL = new ClienteBLL();
            dataGridViewCliente.DataSource = clienteBLL.Listar();

            //remover colunas
            
            dataGridViewCliente.Columns[15].Visible = false;
            //renomerar colunas 
            dataGridViewCliente.Columns[0].HeaderText = "ID";
            dataGridViewCliente.Columns[1].HeaderText = "Nome";
            dataGridViewCliente.Columns[2].HeaderText = "CPF";
            dataGridViewCliente.Columns[3].HeaderText = "RG";
            dataGridViewCliente.Columns[4].HeaderText = "REF_COMERCIAIS";
            dataGridViewCliente.Columns[5].HeaderText = "Endereço";
            dataGridViewCliente.Columns[6].HeaderText = "Telefone";
            dataGridViewCliente.Columns[7].HeaderText = "E-mail";
            dataGridViewCliente.Columns[8].HeaderText = "Cidade";
            dataGridViewCliente.Columns[9].HeaderText = "UF";
            dataGridViewCliente.Columns[10].HeaderText = "País";


            //ajustar largura coluna

            dataGridViewCliente.Columns[0].Width = 45;
            dataGridViewCliente.Columns[4].Width = 150;
            dataGridViewCliente.Columns[1].Width = 150;
            dataGridViewCliente.Columns[2].Width = 60;
            dataGridViewCliente.Columns[11].Width = 60;
            dataGridViewCliente.Columns[3].Width = 65;
            dataGridViewCliente.Columns[6].Width = 80;
            dataGridViewCliente.Columns[8].Width = 80;
            dataGridViewCliente.Columns[14].Width = 80;
            dataGridViewCliente.Columns[5].Width = 195;
            dataGridViewCliente.Columns[7].Width = 140;
            dataGridViewCliente.Columns[9].Width = 45;
            dataGridViewCliente.Columns[10].Width = 55;
            dataGridViewCliente.Columns[12].Width = 145;
            dataGridViewCliente.Columns[13].Width = 45;
            dataGridViewCliente.Columns[15].Width = 45;
            
        }
        #endregion
        #region Limpar
        //metodo para limpar 
        public void Limpar()
        {
            txtCodigo.Clear();
            txtNome.Clear();
            txtCidade.Clear();
            txtBairro.Clear();
            txtEmail.Clear();
            txtEndereco.Clear();
            txtNacionalidade.Clear();
            txtPais.Clear();
            txtRefComerciais.Clear();
            txtRG.Clear();
            cbSexo.SelectedIndex = -1;
            cbUF.SelectedIndex = -1;
            mtbCEP.Clear();
            mtbCPF.Clear();
            mtbTelefone.Clear();
            cbSexo.BackColor = Color.White;
            mtbCPF.BackColor = Color.White;
            txtNome.BackColor = Color.White;


        }
        #endregion
        #region Salvar
        private void Salvar(Cliente cliente)

        {
            ClienteBLL clienteBLL = new ClienteBLL();

            if (txtNome.Text.Trim() == string.Empty || txtNome.Text.Trim().Length < 3)
            {
                MessageBox.Show("O campo nome não pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cbSexo.BackColor = Color.White;
                mtbCPF.BackColor = Color.White;
                txtNome.BackColor = Color.LightCoral;
            }
            else if (!mtbCPF.MaskCompleted)
            {
                MessageBox.Show("O campo cpf nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome.BackColor = Color.White;
                cbSexo.BackColor = Color.White;
                mtbCPF.BackColor = Color.LightCoral;

            }
            else if (cbSexo.Text == string.Empty)
            {
                MessageBox.Show("O campo sexo nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome.BackColor = Color.White;

                mtbCPF.BackColor = Color.White;
                cbSexo.BackColor = Color.LightCoral;
            }
            else
            {

                cliente.Nome = txtNome.Text;
                mtbCPF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                cliente.Cpf = mtbCPF.Text;
                cliente.Rg = txtRG.Text;
                cliente.RefComerciais = txtRefComerciais.Text;
                cliente.Endereco = txtEndereco.Text;
                mtbTelefone.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;//remove a mascara
                cliente.Telefone = mtbTelefone.Text;
                cliente.Email = txtEmail.Text;
                cliente.Cidade = txtCidade.Text;
                cliente.Estado = cbUF.Text;
                cliente.Pais = txtPais.Text;
                mtbCEP.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                cliente.Cep = mtbCEP.Text;
                cliente.Nascimento = dtNascimento.Text;
                cliente.Sexo = cbSexo.Text;
                cliente.Nacionalidade = txtNacionalidade.Text;
                cliente.Bairro = txtBairro.Text;

                
                    clienteBLL.Salvar(cliente);
                    MessageBox.Show("Cadastro realizado com sucesso!", "Aviso",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                    Limpar();
                
            }

        }
        #endregion
        #region Alterar
        private void Alterar(Cliente cliente)
        {

            ClienteBLL clienteBLL = new ClienteBLL();

            if (txtNome.Text.Trim() == string.Empty || txtNome.Text.Trim().Length < 3)
            {
                MessageBox.Show("O campo nome não pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                cbSexo.BackColor = Color.White;
                mtbCPF.BackColor = Color.White;
                txtNome.BackColor = Color.LightCoral;
            }
            else if (!mtbCPF.MaskCompleted)
            {
                MessageBox.Show("O campo cpf nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome.BackColor = Color.White;
 
                cbSexo.BackColor = Color.White;
                mtbCPF.BackColor = Color.LightCoral;

            }
            else if (cbSexo.Text == string.Empty)
            {
                MessageBox.Show("O campo sexo nao pode ficar vazio", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtNome.BackColor = Color.White;

                mtbCPF.BackColor = Color.White;
                cbSexo.BackColor = Color.LightCoral;
            }
            else
            {
                cliente.Id = Convert.ToInt32(txtCodigo.Text);
                cliente.Nome = txtNome.Text;
                mtbCPF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                cliente.Cpf = mtbCPF.Text;
                cliente.Rg = txtRG.Text;
                cliente.RefComerciais = txtRefComerciais.Text;
                cliente.Endereco = txtEndereco.Text;
                mtbTelefone.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;//remove a mascara
                cliente.Telefone = mtbTelefone.Text;
                cliente.Email = txtEmail.Text;
                cliente.Cidade = txtCidade.Text;
                cliente.Estado = cbUF.Text;
                cliente.Pais = txtPais.Text;
                mtbCEP.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
                cliente.Cep = mtbCEP.Text;
                cliente.Nascimento = dtNascimento.Text;
                cliente.Sexo = cbSexo.Text;
                cliente.Nacionalidade = txtNacionalidade.Text;
                cliente.Bairro = txtBairro.Text;


               clienteBLL.Alterar(cliente);
                MessageBox.Show("Alterado com sucesso!", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpar();
                btnSalvar.Enabled = true;
                btnExibir.Enabled = true;
            }
        }
        #endregion
        #region Excluir
        private void Excluir(Cliente cliente)
        {
          ClienteBLL clienteBLL = new ClienteBLL();

            if(txtCodigo.Text == string.Empty)
            {
                MessageBox.Show("Selecione um cadastro para excluir", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (MessageBox.Show("Deseja excluir o cadastro selecionado?", "Alerta", MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button1)== DialogResult.Yes)
            {
                cliente.Id = Convert.ToInt32(txtCodigo.Text);
                clienteBLL.Excluir(cliente);
                MessageBox.Show("Excluido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpar();
                btnSalvar.Enabled = true;
                btnExibir.Enabled = true;
            }
        }
        #endregion

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dtNascimento_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}

