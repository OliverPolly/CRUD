﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRUD.MODEL;
using CRUD.DAL;
using System.Data;

namespace CRUD.BLL
{
    public class ProdutoBLL
    {
        ProdutoDAL produtoDAL = new ProdutoDAL();
        //metodo para salvar
        public void SalvarP(Produto produto)
        {
            try
            {
                produtoDAL.SalvarP(produto);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //metodo para editar 
        public void AlterarP(Produto produto)
        {
            try
            {
                produtoDAL.AlterarP(produto);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //Metodo para Excluir
        public void ExcluirP(Produto produto)
        {
            try
            {
                produtoDAL.ExcluirP(produto);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //METODO PARA LISTAR OS DADOS DO DATAGRID
        public DataTable ListarP()
        {
            try
            {
                DataTable dtP = new DataTable();
                dtP = produtoDAL.ListarP();
                return dtP;
            }
            catch (Exception erro)
            {
                throw erro;
            }
        }
    }
}
