﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRUD.MODEL;
using CRUD.DAL;
using System.Data;

namespace CRUD.BLL
{
    public class ClienteBLL
    {
        ClienteDAL clienteDAL = new ClienteDAL();
        //metodo para salvar
        public void Salvar(Cliente cliente)
        {
            try
            {
                clienteDAL.Salvar(cliente);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //metodo para editar 
        public void Alterar (Cliente cliente)
        {
            try
            {
                clienteDAL.Alterar(cliente);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //Metodo para Excluir
        public void Excluir (Cliente cliente)
        {
            
            try
            {
                clienteDAL.Excluir(cliente);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }


        //METODO PARA LISTAR OS DADOS DO DATAGRID


        public DataTable Listar()
        {
            try
            {
                DataTable dt = new DataTable();
                dt = clienteDAL.Listar();
                return dt;
            }
            catch(Exception erro)
            {
                throw erro;
            }
        }
    }
    //
}
