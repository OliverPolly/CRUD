﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CRUD.MODEL;
using CRUD.DAL;
using System.Data;
namespace CRUD.BLL
{
    public class FuncionarioBLL
    {
        FuncionarioDAL funcionarioDAL = new FuncionarioDAL();
        //metodo para salvar
        public void SalvarF(Funcionario funcionario)
        {
            try
            {
                funcionarioDAL.SalvarF(funcionario);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //metodo para editar 
        public void AlterarF(Funcionario funcionario)
        {
            try
            {
                funcionarioDAL.AlterarF(funcionario);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        //Metodo para Excluir
        public void ExcluirF(Funcionario funcionario)
        {
            try
            {
                funcionarioDAL.ExcluirF(funcionario);
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }


        //METODO PARA LISTAR OS DADOS DO DATAGRID
        public DataTable ListarF()
        {
            try
            {
                DataTable dtF = new DataTable();
                dtF = funcionarioDAL.ListarF();
                return dtF;
            }
            catch (Exception erro)
            {
                throw erro;
            }
        }
    }
}
