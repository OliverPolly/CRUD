﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CRUD.MODEL;
using MySql.Data.MySqlClient;

namespace CRUD.DAL
{
    public class ClienteDAL : Conexao
    {
        MySqlCommand comando = null;
        //metodo para salvar
        public void Salvar (Cliente cliente)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("INSERT INTO tbcliente (nome, CPF, RG, REF_COMERCIAIS, endereço," +
                    "telefone, email, cidade, estado, país, CEP, nascimento, sexo, nacionalidade, Bairro) VALUES " +
                    "(@nome, @CPF, @RG, @REF_COMERCIAIS, @endereço, @telefone, @email, @cidade, @estado, @país, @CEP, @nascimento," +
                    " @sexo,  @nacionalidade, @Bairro)", conexao);

                comando.Parameters.AddWithValue("@nome", cliente.Nome);
                comando.Parameters.AddWithValue("@CPF", cliente.Cpf);
                comando.Parameters.AddWithValue("@RG", cliente.Rg);
                comando.Parameters.AddWithValue("@REF_COMERCIAIS", cliente.RefComerciais);
                comando.Parameters.AddWithValue("@endereço", cliente.Endereco);
                comando.Parameters.AddWithValue("@telefone", cliente.Telefone);
                comando.Parameters.AddWithValue("@email", cliente.Email);
                comando.Parameters.AddWithValue("@cidade", cliente.Cidade);
                comando.Parameters.AddWithValue("@estado", cliente.Estado);
                comando.Parameters.AddWithValue("@país", cliente.Pais);
                comando.Parameters.AddWithValue("@CEP", cliente.Cep);
                comando.Parameters.AddWithValue("@nascimento", DateTime.Parse(cliente.Nascimento).ToString("yyyy-MM-dd"));
                comando.Parameters.AddWithValue("@sexo", cliente.Sexo);
                comando.Parameters.AddWithValue("@nacionalidade", cliente.Nacionalidade);
                comando.Parameters.AddWithValue("@Bairro", cliente.Bairro);
                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para editar
        public void Alterar (Cliente cliente)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("UPDATE tbcliente SET nome = @nome, CPF = @CPF, " +
                    "RG = @RG, REF_COMERCIAIS = @REF_COMERCIAIS, " +
                    "endereço = @endereço, telefone = @telefone, email = @email, " +
                    "cidade = @cidade, estado = @estado, país = @país," +
                    " CEP = @CEP, nascimento = @nascimento, sexo = @sexo, nacionalidade = @nacionalidade, " +
                    "Bairro = @Bairro WHERE id = @id ", conexao);

                comando.Parameters.AddWithValue("@id", cliente.Id);
                comando.Parameters.AddWithValue("@nome", cliente.Nome);
                comando.Parameters.AddWithValue("@CPF", cliente.Cpf);
                comando.Parameters.AddWithValue("@RG", cliente.Rg);
                comando.Parameters.AddWithValue("@REF_COMERCIAIS", cliente.RefComerciais);
                comando.Parameters.AddWithValue("@endereço", cliente.Endereco);
                comando.Parameters.AddWithValue("@telefone", cliente.Telefone);
                comando.Parameters.AddWithValue("@email", cliente.Email);
                comando.Parameters.AddWithValue("@cidade", cliente.Cidade);
                comando.Parameters.AddWithValue("@estado", cliente.Estado);
                comando.Parameters.AddWithValue("@país", cliente.Pais);
                comando.Parameters.AddWithValue("@CEP", cliente.Cep);
                comando.Parameters.AddWithValue("@nascimento", DateTime.Parse(cliente.Nascimento).ToString("yyyy-MM-dd"));
                comando.Parameters.AddWithValue("@sexo", cliente.Sexo);
                comando.Parameters.AddWithValue("@nacionalidade", cliente.Nacionalidade);
                comando.Parameters.AddWithValue("@Bairro", cliente.Bairro);
                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para excluir
        public void Excluir (Cliente cliente)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("DELETE FROM tbcliente WHERE id = @id", conexao);

                comando.Parameters.AddWithValue("@id", cliente.Id);
                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para listar

        public DataTable Listar()
        {
            try
            {
                AbrirConexao();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter();
                comando = new MySqlCommand("SELECT * FROM tbcliente ORDER BY id", conexao);

                da.SelectCommand = comando;
                da.Fill(dt);
                return dt;
            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
    }
}
