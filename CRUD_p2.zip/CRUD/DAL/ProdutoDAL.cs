﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CRUD.MODEL;
using MySql.Data.MySqlClient;

namespace CRUD.DAL
{
    public class ProdutoDAL : Conexao
    {
        MySqlCommand comandoP = null;
        //metodo para salvar
        public void SalvarP(Produto produto)
        {
            try
            {
                AbrirConexao();
                comandoP = new MySqlCommand("INSERT INTO vendasprodutos (quantidade, categoria, descricao, valorUnitario, valorTotal, observacao)" +
                    " VALUES (@quantidade, @categoria, @descricao, @valorUnitario, @valorTotal, @observacao)", conexao);

                comandoP.Parameters.AddWithValue("@quantidade", produto.QuantidadeP);
                comandoP.Parameters.AddWithValue("@categoria", produto.CategoriaP);
                comandoP.Parameters.AddWithValue("@descricao", produto.DescricaoP);
                comandoP.Parameters.AddWithValue("@valorUnitario", produto.ValorunitarioP);
                comandoP.Parameters.AddWithValue("@valorTotal", produto.ValortotalP);
                comandoP.Parameters.AddWithValue("@observacao", produto.ObsevacaoP);
                comandoP.ExecuteNonQuery();
            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para editar
        public void AlterarP(Produto produto)
        {
            try
            {
                AbrirConexao();
                comandoP = new MySqlCommand("UPDATE vendasprodutos SET quantidade = @quantidade," +
                    " categoria = @categoria, descricao = @descricao, valorUnitario= @valorUnitario," +
                    " valorTotal= @valorTotal, observacao = @observacao WHERE id = @id ", conexao);
                comandoP.Parameters.AddWithValue("@id", produto.IdP);
                comandoP.Parameters.AddWithValue("@quantidade", produto.QuantidadeP);
                comandoP.Parameters.AddWithValue("@categoria", produto.CategoriaP);
                comandoP.Parameters.AddWithValue("@descricao", produto.DescricaoP);
                comandoP.Parameters.AddWithValue("@valorUnitario", produto.ValorunitarioP);
                comandoP.Parameters.AddWithValue("@valorTotal", produto.ValortotalP);
                comandoP.Parameters.AddWithValue("@observacao", produto.ObsevacaoP);
                comandoP.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para excluir
        public void ExcluirP(Produto produto)
        {
            try
            {
                AbrirConexao();
                comandoP = new MySqlCommand("DELETE FROM vendasprodutos WHERE id = @id", conexao);
                comandoP.Parameters.AddWithValue("@id", produto.IdP);
                comandoP.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para listar

        public DataTable ListarP()
        {
            try
            {
                AbrirConexao();
                DataTable dtP = new DataTable();
                MySqlDataAdapter daP = new MySqlDataAdapter();
                comandoP = new MySqlCommand("SELECT * FROM vendasprodutos ORDER BY id", conexao);

                daP.SelectCommand = comandoP;
                daP.Fill(dtP);
                return dtP;
            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
    }
}
