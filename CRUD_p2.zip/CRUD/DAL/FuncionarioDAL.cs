﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using CRUD.MODEL;
using MySql.Data.MySqlClient;
namespace CRUD.DAL
{
    public class FuncionarioDAL : Conexao
    {
        MySqlCommand comandoF = null;
        //metodo para salvar
        public void SalvarF(Funcionario funcionario)
        {
            try
            {
                AbrirConexao();
                comandoF = new MySqlCommand("INSERT INTO tbfuncionario (nomeF, emailF, funçao, CPF_F, nascimentoF, sexoF, " +
                    "salarioF, nacionalidadeF, Telefone) VALUES (@nomeF, @emailF, @funçao, @CPF_F, @nascimentoF, @sexoF, " +
                    "@salarioF, @nacionalidadeF, @Telefone)", conexao);

                comandoF.Parameters.AddWithValue("@nomeF", funcionario.NomeF);
                comandoF.Parameters.AddWithValue("@emailF", funcionario.EmailF);
                comandoF.Parameters.AddWithValue("@funçao", funcionario.FuncaoF);
                comandoF.Parameters.AddWithValue("@CPF_F", funcionario.CpfF);
                comandoF.Parameters.AddWithValue("@nascimentoF", DateTime.Parse(funcionario.NascimentoF).ToString("yyyy-MM-dd"));
                comandoF.Parameters.AddWithValue("@sexoF", funcionario.SexoF);
                comandoF.Parameters.AddWithValue("@salarioF", Convert.ToDouble( funcionario.SalarioF));
               
                comandoF.Parameters.AddWithValue("@nacionalidadeF", funcionario.NacionalidadeF);
                comandoF.Parameters.AddWithValue("@Telefone", funcionario.Telefone);
                comandoF.ExecuteNonQuery();
            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }

        }
        //metodo para editar
        public void AlterarF(Funcionario funcionario)
        {
            try
            {
                AbrirConexao();
                comandoF = new MySqlCommand("UPDATE tbfuncionario SET nomeF = @nomeF, emailF = @emailF, funçao = @funçao," +
                    " CPF_F = @CPF_F, nascimentoF = @nascimentoF, sexoF = @sexoF, " +
                    "salarioF = @salarioF, nacionalidadeF = @nacionalidadeF, Telefone = @Telefone" +
                    "  WHERE idF = @idF ", conexao);

                comandoF.Parameters.AddWithValue("@idF", funcionario.IdF);
                
                comandoF.Parameters.AddWithValue("@nomeF", funcionario.NomeF);
                comandoF.Parameters.AddWithValue("@emailF", funcionario.EmailF);
                comandoF.Parameters.AddWithValue("@funçao", funcionario.FuncaoF);
                comandoF.Parameters.AddWithValue("@CPF_F", funcionario.CpfF);
                comandoF.Parameters.AddWithValue("@nascimentoF", DateTime.Parse(funcionario.NascimentoF).ToString("yyyy-MM-dd"));
                comandoF.Parameters.AddWithValue("@sexoF", funcionario.SexoF);
                comandoF.Parameters.AddWithValue("@salarioF", Convert.ToDouble(funcionario.SalarioF));

                comandoF.Parameters.AddWithValue("@nacionalidadeF", funcionario.NacionalidadeF);
                comandoF.Parameters.AddWithValue("@Telefone", funcionario.Telefone);
                comandoF.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para excluir
        public void ExcluirF(Funcionario funcionario)
        {
            try
            {
                AbrirConexao();
                comandoF = new MySqlCommand("DELETE FROM tbfuncionario WHERE idF = @idF", conexao);
                comandoF.Parameters.AddWithValue("@idF", funcionario.IdF);
                comandoF.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        //metodo para listar

        public DataTable ListarF()
        {
            try
            {
                AbrirConexao();
                DataTable dtF = new DataTable();
                MySqlDataAdapter daF = new MySqlDataAdapter();
                comandoF = new MySqlCommand("SELECT * FROM tbfuncionario ORDER BY idF", conexao);

                daF.SelectCommand = comandoF;
                daF.Fill(dtF);
                return dtF;
            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }

    }
}
