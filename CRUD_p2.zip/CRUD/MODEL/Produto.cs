﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.MODEL
{
    public class Produto
    {
        public int IdP { get; set; }
        public String  QuantidadeP { get; set; }
        public String CategoriaP { get; set; }
        public String DescricaoP { get; set; }
        public String ValorunitarioP { get; set; }
        public String ValortotalP { get; set; }
        public String ObsevacaoP { get; set; }
        
    }
}
