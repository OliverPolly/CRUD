﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.MODEL
{
    public class Funcionario
    {
        public int IdF { get; set; }
        public String NomeF { get; set; }
        public String CpfF { get; set; }
        public double SalarioF { get; set; }
        public String FuncaoF { get; set; }
        public String EmailF { get; set; }
        public String NascimentoF { get; set; }
        public String SexoF { get; set; }
        public String NacionalidadeF { get; set; }
        public String Telefone { get; set; }
    }
}
