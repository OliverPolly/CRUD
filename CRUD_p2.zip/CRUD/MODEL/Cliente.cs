﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.MODEL
{
    public class Cliente
    {

        public int Id { get; set; }
        public String Nome { get; set; }
        public String Cpf { get; set; }
        public String Rg { get; set; }
        public String RefComerciais { get; set; }
        public String Endereco { get; set; }
        public String Telefone { get; set; }
        public String Email { get; set; }
        public String Cidade { get; set; }
        public String Estado { get; set; }
        public String Pais { get; set; }
        public String Cep { get; set; }
        public String Nascimento { get; set; }
        public String Sexo { get; set; }
       
        public String Nacionalidade { get; set; }
        public String Bairro { get; set; }
    }
}
