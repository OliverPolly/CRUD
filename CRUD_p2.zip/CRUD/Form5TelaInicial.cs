﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void btnCadastrarCliente_Click(object sender, EventArgs e)
        {
            CadastroDeClientes formCadastroCliente = new CadastroDeClientes();
            formCadastroCliente.Show();
            this.Hide(); 
        }

        private void btnCadastrarFuncionário_Click(object sender, EventArgs e)
        {
            Form4CadastroFuncionario formCadastroFuncionario = new Form4CadastroFuncionario();
            formCadastroFuncionario.Show();
            this.Hide();
        }

        private void btnCadastroProdutos_Click(object sender, EventArgs e)
        {
            Form2CadastroProduto formCadastroProduto = new Form2CadastroProduto();
            formCadastroProduto.Show();
            this.Hide();
        }
    }
}
